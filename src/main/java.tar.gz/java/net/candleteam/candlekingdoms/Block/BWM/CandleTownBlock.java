package net.candleteam.candlekingdoms.Block.BWM;

import net.candleteam.candlekingdoms.BlockEntity.EBlocks.CandleTownBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class CandleTownBlock extends CandleBlock implements EntityBlock {

    public CandleTownBlock(Properties properties) {
        super(properties);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(
            BlockPos pos,
            BlockState state
    ) {
        return new CandleTownBlockEntity(pos, state);
    }
}
