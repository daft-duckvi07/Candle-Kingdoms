package net.candleteam.candlekingdoms.Block;

import net.candleteam.candlekingdoms.Block.BWM.CandleTownBlock;
import net.candleteam.candlekingdoms.Block.BWM.TownBlock;
import net.candleteam.candlekingdoms.CandleKingdoms;
import net.candleteam.candlekingdoms.Item.ModItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;


import java.util.function.Function;
import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(CandleKingdoms.MOD_ID);


    public static final DeferredBlock<Block> UTKA_BLOCK = registerBlock(
            "utka_block",
            properties -> new Block(properties
                    .strength(1f)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.CANDLE)));




    public static final Supplier<Block> CANDLE_TOWN = BLOCKS.registerBlock(
            "candle_town",
            properties -> new CandleTownBlock(properties
                            .strength(0.1F)
                            .sound(SoundType.CANDLE)
            ));

    public static final DeferredBlock<Block> TOWN_BLOCK = registerBlock(
            "town_block",
            properties -> new TownBlock(properties
                    .noCollision()
                    .strength(0.1F)
                    .sound(SoundType.CANDLE)
            ));
    public static final DeferredBlock<Block> ARMY_BLOCK = registerBlock(
            "army_block",
            properties -> new TownBlock(properties
                    .noCollision()
                    .strength(0.1F)
                    .sound(SoundType.CANDLE)
            ));











    private static <T extends Block> DeferredBlock<T> registerBlock(String name, Function<BlockBehaviour.Properties, T> function) {
        DeferredBlock<T> toReturn = BLOCKS.registerBlock(name, function);
        registerBlockItem(name, toReturn);
        return toReturn;
    }

    private static <T extends Block> void registerBlockItem(String name, DeferredBlock<T> block) {
        ModItems.ITEMS.registerItem(name, properties -> new BlockItem(block.get(), properties.useBlockDescriptionPrefix()));
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}